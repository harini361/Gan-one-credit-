from django.shortcuts import render
from django.conf import settings
from huggingface_hub import InferenceClient
import base64
from io import BytesIO

client = InferenceClient(
    provider="nscale",
    api_key=settings.HF_TOKEN
)

def home(request):
    img_base64 = None
    error_message = None

    if request.method == "POST":
        prompt = request.POST.get("prompt", "").strip()

        if prompt:
            try:
                image = client.text_to_image(
                    prompt,
                    model="stabilityai/stable-diffusion-xl-base-1.0",
                )

                buffer = BytesIO()
                image.save(buffer, format="PNG")

                img_base64 = base64.b64encode(buffer.getvalue()).decode()

            except Exception as e:
                error_message = str(e)

    return render(request, "generator/index.html", {
        "image": img_base64,
        "error": error_message
    })